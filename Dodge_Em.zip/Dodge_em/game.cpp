//============================================================================
// Name        : game.cpp
// Author      : Momin Mahmud Jalib
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game of Dodge 'Em...
//============================================================================

#ifndef DODGE_CPP_
#define DODGE_CPP_
#include "util.h"
#include <iostream>
#include<string>
#include<cmath> // for basic math functions such as cos, sin, sqrt
using namespace std;


                                            //*********************  OPPONENT CAR  **********************************
float x = 390; 
float y = 30;
float width = 10; 
float height = 10; 

int o=0;                                      //**********************  USER CAR  **********************************   
float x1= 460;
float y2 = 30;
int menu=0;
int road=1;
int opporoad=1;

int lives=3;
int xfood[72];
int yfood[72];
bool food_bool_variable[72];

int score=0;

 







          
void coordinates()
{
 int q = 0;
  

for(int fy=30; fy<=730 ; fy=fy+100)
   {
       
        for(int fx=80;fx<=780;fx=fx+100)
       {
                xfood[q]=fx;
	        
                yfood[q]=fy;
                
                q++;
       }
	 
   }
}

void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}


/*
 * Main Canvas drawing function.
 * */
//Board *b;
void GameDisplay()/**/{
	// set the background color using function glClearColor.
	// to change the background play with the red, green and blue values below.
	// Note that r, g and b values must be in the range [0,1] where 0 means dim rid and 1 means pure red and so on.

	glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
			0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors




//********************************************** SHOWING CARS  **********************************************************************
        
 DrawString( 50, 800,"Score="+to_string(score), colors[MISTY_ROSE]);
DrawString( 600, 800,"Lives="+to_string(lives), colors[MISTY_ROSE]);

	// calling some functions from util.cpp file to help students

	//Square at 400,20 position
	//DrawSquare( 400 , 20 ,40,colors[RED]); 
	//Square at 250,250 position
	//DrawSquare( 250 , 250 ,20,colors[GREEN]); 
	//Display Score
	//DrawString( 50, 800, "Score=0", colors[MISTY_ROSE]);
	//Triangle at 300, 450 position
	//DrawTriangle( 300, 450 , 340, 450 , 320 , 490, colors[MISTY_ROSE] ); 
	// Trianlge Vertices v1(300,50) , v2(500,50) , v3(400,250)
	//Circle at 50, 670 position
	//DrawCircle(50,670,10,colors[RED]);
	//Line from 550,50 to 550,480 with width 10
	//DrawLine(int x1, int y1, int x2, int y2, int lwidth, float *color)
	//DrawLine( 550 , 50 ,  550 , 480 , 10 , colors[MISTY_ROSE] );	
	
if (menu==0){

DrawRectangle(0,0,840,840,colors[BLUE]);
DrawCircle(420,420,400,colors[RED]);
DrawString(300,700," PRESS P TO PLAY ",colors[BLACK]);
DrawString(300,550," PRESS E TO EXIT ",colors[BLACK]);
DrawString(300,400," PRESS I FOR INFO ",colors[BLACK]);

}


if (menu==2){
DrawRectangle(0,0,840,840,colors[ORANGE]);
DrawString(150,700," > WELCOME TO DODGE E'M ",colors[BLACK]);	
DrawString(150,600," > PRESS LEFT KEY TO GO LEFT ",colors[BLACK]);
DrawString(150,500," > PRESS RIGHT KEY TO GO RIGHT ",colors[BLACK]);
DrawString(150,400," > PRESS UP KEY TO GO UP ",colors[BLACK]);
DrawString(150,300," > PRESS DOWN KEY TO GO DOWN ",colors[BLACK]);
DrawString(150,200," > PRESS UP KEY TO GO UP ",colors[BLACK]);
DrawString(150,100," > DODGE THE CAR AND COLLECT ALL COINS ",colors[BLACK]);
}


if (menu==1)






{

//**********************************************  DRAWING CARS  **************************************************************************

        // Drawing opponent car
	 
	 
	float width = 8; 
	float height = 8;
	float* color = colors[RED]; 
	float* color1 = colors[GREEN]; 
	float radius = 3.0;
	DrawRoundRect(x,y,width,height,color,radius); // bottom left tyre
	DrawRoundRect(x+width*3,y,width,height,color,radius); // bottom right tyre
	DrawRoundRect(x+width*3,y+height*4,width,height,color,radius); // top right tyre
	DrawRoundRect(x,y+height*4,width,height,color,radius); // top left tyre
	DrawRoundRect(x, y+height*2, width, height, color, radius/2); // body left rect
	DrawRoundRect(x+width, y+height, width*2, height*3, color, radius/2); // body center rect
	DrawRoundRect(x+width*3, y+height*2, width, height, color, radius/2); // body right rect

	



         //car
	 width = 8; 
	 height = 8;
	 color = colors[BLUE];
        color1 = colors[GREEN];
	radius = 3.0;
	DrawRoundRect(x1,y2,width,height,color1,radius); // bottom left tyre
	DrawRoundRect(x1+width*3,y2,width,height,color1,radius); // bottom right tyre
	DrawRoundRect(x1+width*3,y2+height*4,width,height,color1,radius); // top right tyre
	DrawRoundRect(x1,y2+height*4,width,height,color1,radius); // top left tyre
	DrawRoundRect(x1, y2+height*2, width, height, color, radius/2); // body left rect
	DrawRoundRect(x1+width, y2+height, width*2, height*3, color, radius/2); // body center rect
	DrawRoundRect(x1+width*3, y2+height*2, width, height, color, radius/2); // body right rect
       


                                           
	 

        
	 //*************************************************  DRAWING ARENA    ***********************************************
	



        int gap_turn =10;
	int sx = 20;
	int sy = 10;
	int swidth = (800/2- gap_turn/2); // half width
	int sheight =10;
	float *scolor = colors[MAROON];
	DrawRectangle(sx-20, sy, swidth+40, sheight, scolor); // bottom left
	DrawRectangle(sx + swidth + gap_turn+30, sy, swidth+10, sheight, scolor); // bottom right
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight, sheight*2, swidth-60, scolor); // right down
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight+swidth+gap_turn, sheight*2, swidth-60, scolor); // right up
	DrawRectangle(sx-30 + swidth+40 + gap_turn, sy+750, swidth+40, sheight, scolor); // top left
	DrawRectangle(sx-20, sy+750, swidth, sheight, scolor); // top right
	DrawRectangle(sx-sheight*2, sy+sheight+swidth+gap_turn, sheight*2, swidth-60, scolor); // left up
	DrawRectangle(sx-sheight*2, sy+sheight, sheight*2, swidth-60, scolor); // left down

	   //Drawing 2nd arena
        gap_turn = 90;
	int sx1 = 140;
	int sy1 = 80;
        swidth = 580/2 - gap_turn/2; // half width
        sheight = 10;
	float *scolor1 = colors[MISTY_ROSE];
	DrawRectangle((sx1-15), sy1+10, swidth, sheight, scolor1); // bottom left
	DrawRectangle((sx1+10) + swidth + gap_turn, sy1+10, swidth, sheight, scolor1); // bottom right
	DrawRectangle((sx1+10)+swidth*2+gap_turn, sy1+sheight, sheight*2, swidth, scolor1); // right down
	DrawRectangle((sx1+10)+swidth*2+gap_turn, sy1+sheight+swidth+gap_turn, sheight*2, swidth, scolor1); // right up
	DrawRectangle((sx1+10) + swidth + gap_turn, sy1+580, swidth, sheight, scolor1); // top left
	DrawRectangle((sx1-15), sy1+580, swidth, sheight, scolor1); // top right
	DrawRectangle((sx1-sheight*2)-15, sy1+sheight+swidth+gap_turn, sheight*2, swidth, scolor1); // left up
	DrawRectangle((sx1-sheight*2)-10, sy1+sheight, sheight*2, swidth, scolor1); // left down

        
        
        //Drawing 3rd arena
       
        gap_turn = 100;
	int sx2 = 225;
	int sy2 = 170;
        swidth = 400/2 - gap_turn/2; // half width
        sheight = 10;
	float *scolor2 = colors[ORANGE];
	DrawRectangle(sx2, sy2+10, swidth, sheight, scolor2); // bottom left
	DrawRectangle(sx2 + swidth + gap_turn, sy2+10, swidth, sheight, scolor2); // bottom right
	DrawRectangle(sx2+swidth*2+gap_turn, sy2+sheight, sheight*2, swidth, scolor2); // right down
	DrawRectangle(sx2+swidth*2+gap_turn, (sy2+sheight+swidth+gap_turn)+20, sheight*2, swidth, scolor2); // right up
	DrawRectangle(sx2 + swidth + gap_turn, sy2+420, swidth, sheight, scolor2); // top left
	DrawRectangle(sx2, sy2+420, swidth, sheight, scolor2); // top right
	DrawRectangle(sx2-sheight*2, (sy2+sheight+swidth+gap_turn)+20, sheight*2, swidth, scolor2); // left up
	DrawRectangle(sx2-sheight*2, sy2+sheight, sheight*2, swidth, scolor2); // left down
            
          //Drawing 4th arena 
          gap_turn = 100;
	int sx4 = 330;
	int sy4 = 312;
        swidth = 190/2 - gap_turn/2; // half width
        sheight = 10;
	float *scolor4 = colors[ORANGE];
	DrawRectangle(sx4, sy4-60, swidth, sheight, scolor4); // bottom left
	DrawRectangle(sx4 + swidth + gap_turn, sy4-60, swidth, sheight, scolor4); // bottom right
	DrawRectangle(sx4+swidth*2+gap_turn, (sy4+sheight)-70, sheight*2, swidth, scolor4); // right down
	DrawRectangle(sx4+swidth*2+gap_turn, (sy4+sheight+swidth+gap_turn)-10, sheight*2, swidth, scolor4); // right up
	DrawRectangle(sx4 + swidth + gap_turn, sy4+180, swidth, sheight, scolor4); // top left
	DrawRectangle(sx4, sy4+180, swidth, sheight, scolor4); // top right
	DrawRectangle(sx4-sheight*2, (sy4+sheight+swidth+gap_turn)-10, sheight*2, swidth, scolor4); // left up
	DrawRectangle(sx4-sheight*2, (sy4+sheight)-70, sheight*2, swidth, scolor4); // left down





         //Drawing fifth and last arena

         gap_turn = 0;
	int sx3 = 400;
	int sy3 = 350;
        swidth = 50/2 - gap_turn/2; // half width
        sheight = 4;
	float *scolor3 = colors[YELLOW];
	DrawRectangle(sx3, sy3+5, swidth, sheight+10, scolor2); // bottom left
	DrawRectangle(sx3 + swidth + gap_turn, sy3+5, swidth, sheight+10, scolor2); // bottom right
	DrawRectangle(sx3+swidth*2+gap_turn, sy3+sheight, sheight*2, swidth, scolor2); // right down
	DrawRectangle(sx3+swidth*2+gap_turn, sy3+sheight+swidth+gap_turn, sheight*2, swidth, scolor2); // right up
	DrawRectangle(sx3 + swidth + gap_turn, sy3+40, swidth, sheight+10, scolor2); // top left
	DrawRectangle(sx3, sy3+40, swidth, sheight+10, scolor2); // top right
	DrawRectangle(sx3-sheight*2, sy3+sheight+swidth+gap_turn, sheight*2, swidth, scolor2); // left up
	DrawRectangle(sx3-sheight*2, sy3+sheight, sheight*2, swidth, scolor2); // left down


 for(int q=0; q<72; q++)
   {
           if(food_bool_variable[q]==false)
           {
           DrawCircle(xfood[q],yfood[q],7,colors[YELLOW]);
           }
   }
       
   }

	glutSwapBuffers(); // do not modify this line.. or draw anything below this line
}

/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */

void NonPrintableKeys(int key, int x11, int y11) {
	if (key== GLUT_KEY_LEFT /*GLUT_KEY_LEFT is constant and contains ASCII for left arrow key*/) 
		// what to do when left key is pressed...
      {     
	   
	 if(y>=330&&y<=390){

                            if(x>500&&x<=760){

			    x-=90;
				road++;} 

                                  } 
			if(y>=330&&y<=390){ 

                              if(x>50&&x<=320){

				x-=90;

				road--;

}



              }

	}		


          
	 else if (key== GLUT_KEY_RIGHT/* GLUT_KEY_RIGHT is constant and contains ASCII for right arrow key*/) {

            

		   if(y>=330&&y<=390){

                         if(x>=50&&x<320){

			    x+=90;

				road++;}

                                     }

			if(y>=330&&y<=390){

                             if(x>=478&&x<=691){

				x+=90;

				road--;}

                                      }

		   
	

	} else if (key== GLUT_KEY_UP/*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/) {

           

                 if(x>=374&&x<=444){

                            if(y>=30&&y<300){

				y+=90;

                                road++;

                                          }

                                        }

                        if(x>=374&&x<=444) {

                               if (y>=420&&y<690){

                                y+=90;

                                road--;}

          }


	}



	else if (key== GLUT_KEY_DOWN/*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/) {

                   if(x>=374&&x<=444){

                                     if(y>40&&y<=310){

                                y-=90;

                                road--;}

                            }

                   if(x>=374&&x<=444){ 

                                if(y>460&&y<=690){

                                y-=90;

                               road++;}

                               }


	}



   




	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

        

	glutPostRedisplay();

}





 
void PrintableKeys(unsigned char key, int x, int y) {
	if (key == 27/* Escape key ASCII*/) {
		exit(1); // exit the program when escape key is pressed.
	}

	if (key == 'b' || key == 'B')
			{
		//do something if b is pressed




		cout << "b pressed" << endl;
         
//*********************************************           MENU KEYS   *************************************************************************
	}




    if(key=='E'||key=='e'){
          exit(1);

}
    if(key=='P'||key=='p'){
          menu=1;
}
    if(key=='I'||key=='i'){
          menu=2;
}


     
	glutPostRedisplay();
}

/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */ 
 

 int speed=2;
void Timer(int m) {


//*******************************************************  USER CAR   *****************************************************************  
	

if(road==1)

{



        if(x>=50&&y==30)

         
           {

              x-=speed;

           }

        if(y<=690&&x==50)

           {

              y+=speed;

           }

        if(x<=760&&y==690)

           {

           x+=speed;

           }

        if(y>=30&&x==760)
            
           {

           y-=speed ;
            
           }



         

}

        
       



if (road==2){


        if(y<=600&&x==140)

         {

         y+=speed;

         }

         if(x<=670&&y==600)

         {

         x+=speed;

         }

         if(y>=120&&x==670)

         {

         y-=speed;

         }

         if(x>=140&&y==120){

         x-=speed ;
         }
         

}
  


   if (road==3) {   
        if(y<=510&&x==230)

         {

         y+=speed;

         }

         if(x<=580&&y==510)

         {

         x+=speed;

         }

         if(y>=210&&x==580)

         {

         y-=speed;

         }

         if(x>=230&&y==210){

         x-=speed ;
         }

}
   if (road==4){

        if(y<=420&&x==320)

         {

         y+=speed;

         }

         if(x<=490&&y==420)

         {

         x+=speed;

         }

         if(y>=300&&x==490)

         {

         y-=speed;

         }

         if(x>=320&&y==300){

         x-=speed ;
         }
  }
 




    if (opporoad==1){
                     //****************************************        OPPONENT CAR        ******************************************
  if(x1<=760 && y2==30)

         {

         x1+=speed;


         }



          if(y2<=690&&x1==760)

         {

         y2+=speed;

         }



        if(x1>=50&&y2==690)

         {

         x1-=speed;

         }

       } 
        

         if(y2>=30&&x1==50){

         y2-=speed ;

}


 if (opporoad==2)
{
          
            if(x1>=140&&y2==600){

         x1-=speed ;
     }

          if(y2>=120&&x1==140)

         {

         y2-=speed;

         }

         if(x1<=670&&y2==120)

         {

         x1+=speed;

         }
        if(y2<=600&&y2>50&&x1==670)

         {

         y2+=speed;

         }
}
if (opporoad==3)
{
      
              if(x1>=230&&y2==510){

         x1-=speed ;
    

     }
     if(y2>=210&&x1==230)

         {

         y2-=speed;

         }
   if(x1<=580&&y2==210)

         {

         x1+=speed;
}
      if(y2<=510&&x1==580)

         {

         y2+=speed;

         }

      

         

}
if (opporoad==4){



     if(x1>=320&&y2==420){

         x1-=speed ;
         }
              
      if(y2>=300&&x1==320)

         {

         y2-=speed;

         }

    if(x1<=490&&y2==300)

         {

         x1+=speed;

         }

   

if(y2<=420&&x1==490)

         {

         y2+=speed;

         }

     
    
			
}

          //**********************************    LEVEL 1 IMPLEMENTATION ******************************************************************
if(road<opporoad){
            

		 

			

		   
	

	

                        if(x1>=374&&x1<=444) {

                               if (y2>=420&&y2<690){

                                y2+=90;

                                opporoad--;}

          }


	



	

                   if(x1>=374&&x1<=444){

                                     if(y2>40&&y2<=310){

                                y2-=90;

                                opporoad--;}

                            }



	





}
if(road>opporoad)
{


           

                 if(x1>=374&&x1<=444){

                            if(y2>=30&&y2<300){

				y2+=90;

                                opporoad++;

                                          }

                                        }

                     

                   if(x1>=374&&x1<=444){ 

                                if(y2>460&&y2<=690){

                                y2-=90;

                               opporoad++;}

                               }


	
}



  




     
//***************************************************** AFTER COLLISION  ***********************************************************
 
if(x-x1<=20 && y-y2<=40 && x1-x<=20 && y2-y<=40){
          x=390;
          y=30;
          x1=460;
          y2=30;
          road=1;
          opporoad=1;
          lives--;
          if (lives==0){
exit(1);
}
}
//**************************************************************************************************************************************
      for(o=0;o<72;o++)
    {
          
         if(food_bool_variable[o]==false)
       {
         if((x<=xfood[o] && x+width*6>=xfood[o])&&(y<=yfood[o] && y+height*6>=yfood[o]))
         {
            food_bool_variable[o]=true;
            score=score+10;
         }
      
       }
    }
/*
********************************************************  LEVEL 2 ****************************************************************************
   



          
if(road<opporoad){
            

		 

			
  
			if(y2>=330&&y2<=390){ 

                              if(x1>50&&x1<=320){

				y2-=90;

				opporoad--;

}



              }

			


          
	 

            


			if(y2>=330&&y2<=390){

                             if(x1>=478&&x1<=691){

				x1+=90;

				opporoad--;}

                                      }

		   
	

	


	

                        if(x1>=374&&x1<=444) {

                               if (y2>=420&&y2<690){

                                y2+=90;

                                opporoad--;}

          }


	



	

                   if(x1>=374&&x1<=444){

                                     if(y2>40&&y2<=310){

                                y2-=90;

                                opporoad--;}

                            }



	





}
if(road>opporoad)
{






              
   if(y2>=330&&y2<=390){

                         if(x1>=50&&x1<320){

			    x1+=90;

				opporoad++;}

                                     }

		 if(y2>=330&&y2<=390){

                            if(x1>500&&x1<=760){

			    x1-=90;
				opporoad++;} 
	

}
          
		

			
		   
	


           

                 if(x1>=374&&x1<=444){

                            if(y2>=30&&y2<300){

				y2+=90;

                                opporoad++;

                                          }

                                        }

                     

                   if(x1>=374&&x1<=444){ 

                                if(y2>460&&y2<=690){

                                y2-=90;

                               opporoad++;}

                               }


	
}

}

*/




         //cout<<"x="<<x<<"  y="<<y<<endl;
         //if(playercordinates == enemycodiantese ){ ///game over}  
        
      //for(int i; i< length; i++){// for checkin
//if()
//}
	// once again we tell the library to call our Timer function after next 1000/FPS

    

  
	glutTimerFunc(100.0/FPS, Timer, 0);
        glutPostRedisplay();
}


/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x, int y) {
	cout << x << " " << y << endl;
	glutPostRedisplay();
}
void MouseMoved(int x, int y) {

	glutPostRedisplay();
}




             //MESSING WITH THE COLLOISON




/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y) {

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
			{
		cout << GLUT_DOWN << " " << GLUT_UP << endl;

	} else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
			{

	}
	glutPostRedisplay();
}
/*
 * our gateway main function
 * */
int main(int argc, char*argv[]) {

	//b = new Board(60, 60); // create q new board object to use in the Display Function ...
     
        for(int g=0;g<72;g++)
	{
	 	food_bool_variable[g]=false;
	}
         coordinates();
	int width = 840, height = 840; // i have set my window size to be 800 x 600
	//b->InitalizeBoard(width, height);
	InitRandomizer(); // seed the random number generator...
	glutInit(&argc, argv); // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50); // set the initial position of our window
	glutInitWindowSize(width, height); // set the size of our window
	glutCreateWindow("OOP Centipede"); // set the title of our game window
	SetCanvasSize(width, height); // set the number of pixels...
 

	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved); // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse

	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
}
#endif /* AsteroidS_CPP_ */

